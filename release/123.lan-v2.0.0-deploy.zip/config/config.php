<?php
if (!defined('NAV_ENTRY')) { http_response_code(403); exit('forbidden'); }
/**
 * 导航站 v2 站点配置
 *
 * 部署到宝塔时只需要改这个文件，不要改 api/ 下的业务代码。
 * 兼容 PHP 7.4（NTS）。
 */

$webRoot = __DIR__;                 // <站点根>/config
$siteRoot = dirname($webRoot);      // <站点根>

return [

    /* ==================== 数据库 ==================== */

    // SQLite 主库位置。
    // 默认放在站点根目录的「上一级」，这样 HTTP 访问不到，避免 data.db 被直接下载。
    // 例如站点是 /www/wwwroot/123.lan/，库就是 /www/wwwroot/123.lan-data/data.db
    // 想放别处：设置环境变量 NAV_DB_FILE 即可，不用改代码。
    'db_file' => (getenv('NAV_DB_FILE') !== false && getenv('NAV_DB_FILE') !== '')
        ? getenv('NAV_DB_FILE')
        // rtrim 是为了站点根直接挂在 / 下时（如 /site）不拼出 //xxx-data 这种双斜杠路径
        : rtrim(dirname($siteRoot), '/\\') . '/' . basename($siteRoot) . '-data/data.db',

    // 老库位置（v1 在站点根下的 data.db）。首次启动会自动迁移过去。
    'db_legacy_file' => $siteRoot . '/data.db',

    // 如果上面那个目录没权限创建，自动退回站点根下的 storage/
    'db_fallback_dir' => $siteRoot . '/storage',

    /* ==================== 上传 ==================== */

    // 必须在站点根下，否则浏览器取不到图标
    'upload_dir' => $siteRoot . '/uploads',
    'upload_url' => '/uploads',
    'upload_allowed_ext' => ['png', 'jpg', 'jpeg', 'gif', 'webp', 'ico', 'svg'],
    'upload_max_bytes' => 2097152,   // 2MB

    /* ==================== 图标 ==================== */

    // 自动抓取站点 favicon 的超时（秒）
    'favicon_timeout' => 5,
    // 抓取结果的缓存时长（秒），默认 7 天。设为 0 表示永不过期。
    'favicon_cache_ttl' => 604800,
    // 抓 favicon 时是否跳过 HTTPS 证书校验。
    // 局域网里的 NAS / 软路由大多是自签证书，保持 true 才能抓到图标。
    'favicon_insecure' => true,

    // 在线图标库（Iconify）。前端不直连，统一走本站代理，避免跨域。
    'iconify_api' => 'https://api.iconify.design',
    'iconify_fallbacks' => ['https://api.simplesvg.com', 'https://api.unisvg.com'],

    /* ==================== 会话 ==================== */

    'session_name' => 'nav_sid',
    // 登录有效期（秒），默认 7 天
    'session_lifetime' => 604800,

    /* ==================== 其它 ==================== */

    'debug' => false,
];
