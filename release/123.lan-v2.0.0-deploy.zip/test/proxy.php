<?php
/**
 * 通用模型 API 代理
 * 用于绕过浏览器的跨域(CORS)限制，转发 OpenAI 兼容接口的请求。
 * 前端通过 POST 提交 { base_url, api_key, path, method, body }，此处转发到目标模型服务。
 */

// 允许跨域（前端同源调用时也可以去掉，这里保留无妨）
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// 仅接受 POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    respondJson(['error' => '仅支持 POST 请求']);
}

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    http_response_code(400);
    respondJson(['error' => '请求体不是合法 JSON']);
}

$baseUrl = rtrim(trim($input['base_url'] ?? ''), '/');
$apiKey  = trim($input['api_key'] ?? '');
$path    = $input['path'] ?? '/v1/models';
$method  = strtoupper($input['method'] ?? 'GET');
$body    = $input['body'] ?? null;
$timeout = isset($input['timeout']) ? intval($input['timeout']) : 300;

if ($baseUrl === '') {
    http_response_code(400);
    respondJson(['error' => '缺少 API 地址']);
}

// 拼接完整 URL，仅允许 http/https，避免意外协议
$url = $baseUrl . '/' . ltrim($path, '/');

$scheme = parse_url($url, PHP_URL_SCHEME);
if ($scheme !== 'http' && $scheme !== 'https') {
    http_response_code(400);
    respondJson(['error' => '仅支持 http/https 地址']);
}

if (!function_exists('curl_init')) {
    http_response_code(500);
    respondJson(['error' => '服务器未启用 PHP curl 扩展']);
}

// 是否流式请求（SSE）
$isStream = false;
if ($method === 'POST' && is_array($body) && !empty($body['stream'])) {
    $isStream = true;
}

$headers = ['Content-Type: application/json'];
if ($apiKey !== '') {
    $headers[] = 'Authorization: Bearer ' . $apiKey;
}
if ($isStream) {
    $headers[] = 'Accept: text/event-stream';
}

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => false,     // 流式直接输出
    CURLOPT_HEADER         => false,
    CURLOPT_HTTPHEADER     => $headers,
    CURLOPT_CONNECTTIMEOUT => 10,
    CURLOPT_TIMEOUT        => $timeout,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
]);

if ($method === 'POST') {
    curl_setopt($ch, CURLOPT_POST, true);
    if ($body !== null) {
        $payload = is_string($body) ? $body : json_encode($body, JSON_UNESCAPED_UNICODE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    }
} elseif ($method !== 'GET') {
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
}

// 关键：关闭所有输出缓冲，并通知 nginx 不要缓冲，实现真正的流式输出
while (ob_get_level() > 0) {
    ob_end_clean();
}
ignore_user_abort(true);
set_time_limit(0);

header('Content-Type: ' . ($isStream ? 'text/event-stream' : 'application/json') . '; charset=utf-8');
header('X-Accel-Buffering: no');
header('Cache-Control: no-cache, no-transform');

curl_setopt($ch, CURLOPT_WRITEFUNCTION, function ($curl, $chunk) {
    echo $chunk;
    if (function_exists('flush')) {
        @flush();
    }
    return strlen($chunk);
});

curl_exec($ch);

$error = curl_error($ch);
curl_close($ch);

// 如果发生底层传输错误且还没输出内容，返回 JSON 错误
if ($error !== '') {
    if (!headers_sent()) {
        http_response_code(502);
        header('Content-Type: text/event-stream; charset=utf-8');
    }
    // 模拟一条 SSE error，方便前端统一解析
    echo "data: " . json_encode(['error' => $error], JSON_UNESCAPED_UNICODE) . "\n\n";
    flush();
}

/**
 * 输出 JSON 并结束
 */
function respondJson($data) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}